package practica8;
import java.util.Scanner;
/**
 * <h2>PrimaMainMetodos.java</h2>
 * <h3>Clase para calcular el tipo de prima que corresponde a cada empleado</h3>
 * <p>Cada prima queda determinada por las caracter�sticas de cada empleado:</p>
 * <ul>
 * <li>Puesto que ocupa en la empresa</li>
 * <li>Meses trabajados en la empresa</li>
 * </ul>
 * <p><strong>Tipos de Primas</strong></p>
 * <ul>
 * <li>P1</li>
 * <li>P2</li>
 * <li>P3</li>
 * <li>P4</li>
 * </ul>
 * 
 * @author Patricia Robles Mend�vil
 * @since 05/05/2022
 * @version 1.0 
 */


public class PrimaMainMetodos {
		
		/**
		 *  Permite obtener la entrada de datos
		 */
		static Scanner  teclado=new Scanner(System.in);
/**
 * Esta M�todo se encarga de iniciar la ejecuci�n del programa
 * Este es el m�todo principal
 * @param args (Son un array de argumentos con los par�metros que recibe por consola)
 */
		public static void main(String[] args) {
			/**
			 * N�mero entero utilizado para identificaci�n del empleado.
			 */
			int numEmple;
			/**
			 * Cadena de texto donde se indica el nombre del empleado.
			 */
			String nomEmple;
			/**
			 * N�mero entero utilizado para indicar el n�mero de meses que lleva el trabajador en la empresa.
			 */
			int meses;
			/**
			 * indica si su cargo es directivo o no
			 */
			char esDirectivo;
			/**
			 * indica si valor es S� o No
			 */
			char respuesta;
			

			do {
				System.out.println("\nDATOS  EMPLEADO/A");
				numEmple=leerNumEmple();
				nomEmple=leerNomEmple();
				meses=leerMeses();
				esDirectivo=leerEsDirectivo();
				System.out.println("\n\tLe corresponde la prima "+hallarPrima(esDirectivo, meses));
				
				
				System.out.println("\n�CALCULAR MAS PRIMAS? (S/N): ");
				respuesta=teclado.nextLine().toUpperCase().charAt(0);
			}while(respuesta=='S');		
		}

/**
 * M�todo hallarPrima calcula la prima que le corresponde al empleado seg�n los par�metros introducidos
 * @param esDirectivo valor si o no
 * @param meses n�mero de meses lleva trabajador en empresa
 * @return tipo de prima que le corresponde al empleado seg�n los par�metros introducidos 
 */
		public static String hallarPrima(char esDirectivo, int meses) {
			if(esDirectivo=='+') // ES DIRECTIVO
				if(meses>=12)
					return "P1";
				else
					return "P3";
			else 	// NO ES DIRECTIVO
				if(meses>=12)
					return "P2";
				else
					return "P4";
		}
/**M�todo leerNumEmple calcula si el n�mero introducido es correcto
 * El n�mero introducido debe estar ente 100-999
 * Si es incorrecto lo pide de nuevo
 * @return numEmple (n�meroidentificador del empleado)
 */
		
		public static int leerNumEmple() {		
			int numEmple;
			do{
				System.out.println("N�MERO [100-999]: ");
				numEmple = teclado.nextInt();
			}while(numEmple<100 || numEmple>999);		
			teclado.nextLine();
			return numEmple;
		}
		
/**M�todo leerNombre calcula si el nombre introducido es correcto
 * El nombre debe tener como m�ximo 10 caracteres
 * Sino es correcto lo pide de nuevo
 * @return nomEmple (nombre del empleado)
 */
		public static String leerNomEmple() {
			String nomEmple;
			do {
				System.out.println("NOMBRE (max 10 caracteres): ");
				nomEmple = teclado.nextLine();
			}while(nomEmple.length()>10);		
			return nomEmple;
		}
		
/**
 * M�todo leerMeses comprueba que el n�mero de meses es mayor que 0
 * Sino es correcto pide introducirlo de nuevo
 * @return meses (n�mero meses lleva trabajador en la empresa)
 */
		public static int leerMeses() {
			int meses;
			do {
				System.out.println("MESES DE TRABAJO: ");
				meses = teclado.nextInt();
			}while(meses<0);
			teclado.nextLine();
			return meses;
		}
		
/**
 * M�todo leerDirectivo comprueba que se introducen los caracteres correctos "+" o " -"
 * si no es correcto pide volver a introducirlos
 * @return esDirectivo (devuelve S o N)
 */
		public static char leerEsDirectivo() {
			char esDirectivo;
			do {
				System.out.println("�ES DIRECTIVO? (+/-): ");
				esDirectivo = teclado.nextLine().charAt(0);
			}while(esDirectivo!='+' && esDirectivo!='-');
			return esDirectivo;
		}
	}

